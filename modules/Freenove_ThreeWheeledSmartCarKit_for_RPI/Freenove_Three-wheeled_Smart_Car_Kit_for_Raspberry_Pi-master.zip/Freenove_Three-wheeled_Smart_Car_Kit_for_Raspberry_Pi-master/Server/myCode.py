#-*- coding: utf-8 -*-
#Import classes, functions, variables, from "mdev" files
from mDev import *
mdev = mDEV()                       #create object
mdev.move(0,0,30)             #Car TurnRight

